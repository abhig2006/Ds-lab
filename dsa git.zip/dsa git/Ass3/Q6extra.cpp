// 1. Given an array A, find the nearest smaller element for every element A[i] in the array such
// that the element has an index smaller than i.
// https://www.interviewbit.com/problems/nearest-smaller-element/