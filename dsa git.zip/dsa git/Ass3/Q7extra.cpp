// 2. Design a stack that supports getMin() in O(1) time and O(1) extra space.
// https:www.geeksforgeeks.org/design-a-stack-that-supports-getmin-in-o1-time-and-o1-extra-space/