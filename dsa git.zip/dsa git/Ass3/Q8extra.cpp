// 3. Given an array arr[ ] of integers, the task is to find the Next Greater Element for each
// element of the array in order of their appearance in the array. Note: The Next Greater Element
// for an element x is the first greater element on the right side of x in the array. Elements for
// which no greater element exist, consider the next greater element as -1.
// Next Greater Element (NGE) for every element in given Array - GeeksforGeeks