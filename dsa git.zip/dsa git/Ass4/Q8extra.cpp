// 3) Given a Queue consisting of first n natural numbers (in random order). The task is to check
// whether the given Queue elements can be arranged in increasing order in another Queue using a
// stack. The operation allowed are:
// 1. Push and pop elements from the stack
// 2. Pop (Or Dequeue) from the given Queue.
// 3. Push (Or Enqueue) in the another Queue.
// Input : Queue[] = { 5, 1, 2, 3, 4 }
// Output : Yes
// Check if a queue can be sorted into another queue using a stack - GeeksforGeeks