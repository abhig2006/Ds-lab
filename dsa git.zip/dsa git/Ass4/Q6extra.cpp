// 1) Given a function n, write a function that generates and prints all binary numbers with decimal
// values from 1 to n.
// Input: n = 2
// Output: 1, 10
// https://www.geeksforgeeks.org/interesting-method-generate-binary-numbers-1-n/