// 1) Find two numbers in an array whose difference equals K. Given an array arr[] and a
// positive integer k, the task is to count all pairs (i, j)
// such that i < j and absolute value of(arr[i] - arr[j]) is equal to k.
// https:www.geeksforgeeks.org/dsa/count-pairs-difference-equal-k/