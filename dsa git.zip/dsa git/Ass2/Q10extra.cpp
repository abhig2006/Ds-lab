// 2) String Split Challenge
// You are given a string consisting of lowercase English alphabets. Your task is to determine
// if it's possible to split this string into three non-empty parts (substrings) where one of
// these parts is a substring of both remaining parts
// https://www.codechef.com/practice/course/nutanix-interview-questions/NUTANIXCON0
// 1/problems/NUTANIX11?tab=statement