// 3) String Anagrams
// Given two strings str1 and str2, determine if they form an anagram pair.
// Note: Two strings are considered anagrams if one string can be rearranged to form the other
// string.
// https://www.codechef.com/practice/course/nutanix-interview-questions/NUTANIXCON0
// 1/problems/NUTANIX01