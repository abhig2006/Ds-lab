// 4) Sort an array of 0s, 1s and 2s - Dutch National Flag Problem
// Given an array arr[] consisting of only 0s, 1s, and 2s. The objective is to sort the array, i.e.,
// put all 0s first, then all 1s and all 2s in last.
// https://www.geeksforgeeks.org/dsa/sort-an-array-of-0s-1s-and-2s/